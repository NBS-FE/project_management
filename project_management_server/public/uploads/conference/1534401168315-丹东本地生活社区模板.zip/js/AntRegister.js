﻿var i = 120;
function flushtime(){
 i--;
 if(i==-1)
 {
    $("#getmobile").attr("disabled",false);
    $("#getmobile").html( "获取验证码") ;
	return null;
 }
  $("#getmobile").html(i + "秒后重发") ;
  $("#getmobile").attr("disabled",true);
  setTimeout("flushtime();",1000);
}
var flag=true;
var total=0;
var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/; //验证邮箱的正则表达式
$.checkMobilePhone = function(value){
	return /^(13\d{9}|17\d{9}|18\d{9}|14\d{9}|15\d{9}|659\d{7}|658\d{7})$/i.test($.trim(value));
}
function checkpassword()
{
	var str = $.trim($("#AntRegUserPwd").val());
	var S_level=checkStrong(str);  		
	$(".pwd").addClass("pw-"+S_level);
	if(str.len()<5 || str.len()>32)
	{
		removeC("AntRegUserPwdTip");
		$("#AntRegUserPwdTip").addClass("o2");
		$("#AntRegUserPwdTip").html("<em></em>密码长度5~32位,请确认");
		flag=false;
	}
	else
	{
		removeC("AntRegUserPwdTip");
		$("#AntRegUserPwdTip").addClass("o4");
		$("#AntRegUserPwdTip").html("");
		flag=true;
		total++;
	}	
	return flag;
}
function checkpassword_()
{
	var str1 = $.trim($("#AntRegUserPwd").val());
	var str = $.trim($("#AntRegUserPwd_").val());
	if(str.len()<5 || str.len()>32)
	{
		removeC("AntRegUserPwd_Tip");
		$("#AntRegUserPwd_Tip").addClass("o2");
		$("#AntRegUserPwd_Tip").html("<em></em>确认密码长度5~32位,请确认");
		flag=false;
	}
	else if(str1!=str)
	{
		removeC("AntRegUserPwd_Tip");
		$("#AntRegUserPwd_Tip").addClass("o2");
		$("#AntRegUserPwd_Tip").html("<em></em>您两次输入的密码不一致,请确认");
		flag=false;
	}
	else
	{
		removeC("AntRegUserPwd_Tip");
		$("#AntRegUserPwd_Tip").addClass("o4");
		$("#AntRegUserPwd_Tip").html("");
		flag=true;
		total++;
	}	
	return flag;
}
function checkcode(tt)
{
	var str = $.trim($("#AntRegUserCode"+tt).val());
	if(str.len()<1)
	{
		removeC("AntRegUserCode"+tt+"Tip");
		$("#AntRegUserCode"+tt+"Tip").addClass("o2");
		$("#AntRegUserCode"+tt+"Tip").html("<em></em>请正确输入图中的验证码");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserCode&AntRegUserCode="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegUserCode"+tt+"Tip");
				$("#AntRegUserCode"+tt+"Tip").addClass("o3");
				$("#AntRegUserCode"+tt+"Tip").html("<em></em>验证码不正确");
				flag=false;
			 }
			 else{
				removeC("AntRegUserCode"+tt+"Tip");
				$("#AntRegUserCode"+tt+"Tip").addClass("o4");
				$("#AntRegUserCode"+tt+"Tip").html("");
				flag=true;
				total++;
			 }
		  }
	  });	
	}
   return flag;
}
function checkq()
{
	var str = $.trim($("#AntRegQuestion").val());
	if(str.len()<1)
	{
		removeC("AntRegQuestionTip");
		$("#AntRegQuestionTip").addClass("o2");
		$("#AntRegQuestionTip").html("<em></em>请输入安全验证答案");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegQuestion&AntRegQuestion="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegQuestionTip");
				$("#AntRegQuestionTip").addClass("o3");
				$("#AntRegQuestionTip").html("<em></em>安全验证答案不正确");
				flag=false;
			 }
			 else{
				removeC("AntRegQuestionTip");
				$("#AntRegQuestionTip").addClass("o4");
				$("#AntRegQuestionTip").html("");
				flag =true;
				total++;
			 }
		  }
	  });	
	}
  return flag;
}
function checkemail()
{
	var str = $.trim($("#AntRegUserEmail").val());
	if(str.len()<5 || str.len() > 30 ) 
	{
		removeC("AntRegUserEmailTip");
		$("#AntRegUserEmailTip").addClass("o2");
		$("#AntRegUserEmailTip").html("<em></em>请输入您的邮箱");
		flag=false;
	}
	else if(!reg.test(str))
	{
		removeC("AntRegUserEmailTip");
		$("#AntRegUserEmailTip").addClass("o2");
		$("#AntRegUserEmailTip").html("<em></em>邮箱格式不正确");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserEmail&AntRegUserEmail="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegUserEmailTip");
				$("#AntRegUserEmailTip").addClass("o3");
				$("#AntRegUserEmailTip").html("<em></em>此邮箱已被注册，<a href='memberlogin.aspx'>立即登录</a>");
				flag=false;
			 }
			 else{
				removeC("AntRegUserEmailTip");
				$("#AntRegUserEmailTip").addClass("o4");
				$("#AntRegUserEmailTip").html("");
				flag=true;
				total++;
			 }
		  }
	  });	
	}
  return flag;
}
function checkmobile()
{
	var str = $.trim($("#AntRegUserMobile").val());
	if(str.len()!=11 && str.len()!=10 ) 
	{
		removeC("AntRegUserMobileTip");
		$("#AntRegUserMobileTip").addClass("o2");
		$("#AntRegUserMobileTip").html("<em></em>请输入您的手机");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserMobile&AntRegUserMobile="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegUserMobileTip");
				$("#AntRegUserMobileTip").addClass("o3");
				$("#AntRegUserMobileTip").html("<em></em>此手机已被注册，<a href='memberlogin.aspx'>立即登录</a>");
				flag=false;
			 }
			 else if(data=="2")
			 {
				removeC("AntRegUserMobileTip");
				$("#AntRegUserMobileTip").addClass("o2");
				$("#AntRegUserMobileTip").html("<em></em>手机格式不正确");
				flag=false;
			 }
			 else{
				removeC("AntRegUserMobileTip");
				$("#AntRegUserMobileTip").addClass("o4");
				$("#AntRegUserMobileTip").html("");
				flag=true;
				total++;
			 }
		  }
	  });	
	}
  return flag;
}
function checkname()
{
	var str = $.trim($("#AntRegUserName").val());
	if(str.len()<3 || str.len()>15)
	{
		removeC("AntRegUserNameTip");
		$("#AntRegUserNameTip").addClass("o2");
		$("#AntRegUserNameTip").html("<em></em>请输入您的用户名，用户名在3-15个字符");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserName&AntRegUserName="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegUserNameTip");
				$("#AntRegUserNameTip").addClass("o3");
				$("#AntRegUserNameTip").html("<em></em>此账户已注册，<a href='memberlogin.aspx'>立即登录</a>");
				flag=false;
			 }
			 else{
				removeC("AntRegUserNameTip");
				$("#AntRegUserNameTip").addClass("o4");
				$("#AntRegUserNameTip").html("");
				flag=true;
				total++;
			 }
		  }
	  });	
	}
  return flag;
}
function checkmobilecode()
{
	var str = $.trim($("#AntRegUserMobilecode").val());
	if(str.len()!=5 ) 
	{
		removeC("AntRegUserMobilecodeTip");
		$("#AntRegUserMobilecodeTip").addClass("o2");
		$("#AntRegUserMobilecodeTip").html("<em></em>请输入手机获取的短信激活码");
		flag=false;
	}
	else
	{
		$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserMobilecode&chrtel="+$("#AntRegUserMobile").val()+"&AntRegUserMobilecode="+escape(str),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			 if(data=="1"){
				removeC("AntRegUserMobilecodeTip");
				$("#AntRegUserMobilecodeTip").addClass("o3");
				$("#AntRegUserMobilecodeTip").html("<em></em>短信激活码不正确");
				flag=false;
			 }
			 else{
				removeC("AntRegUserMobilecodeTip");
				$("#AntRegUserMobilecodeTip").addClass("o4");
				$("#AntRegUserMobilecodeTip").html("");
				flag=true;
				total++;
			 }
		  }
	  });	
	}
  return flag;
}
function getImg()
{
	document.getElementById('image').src = '../VerifyCode/VerifyCode.aspx?key=2&tt=' + Math.random(); return false;
}
$(document).ready(function(){
	$(".in_").focus(function(){
		$(this).parent().addClass("cur");
	});
	$(".in_").blur(function(){
		$(this).parent().removeClass("cur");
	});
	$("#AntRegUserName").focus(function(){
		$("#AntRegUserNameTip").show();
		removeC("AntRegUserNameTip");
		$("#AntRegUserNameTip").addClass("o1");
		$("#AntRegUserNameTip").html("<em></em>会员名在3-15个字符，一旦注册成功会员名不能修改");
	});
	$("#AntRegUserPwd").keyup(function(){
		var str = $.trim($("#AntRegUserPwd").val());
		var S_level=checkStrong(str);  		
		$(".pwd").addClass("pw-"+S_level)
	});
	$("#AntRegUserPwd").focus(function(){
		$("#AntRegUserPwdTip").show();
		removeC("AntRegUserPwdTip");
		$("#AntRegUserPwdTip").addClass("o1");
		$("#AntRegUserPwdTip").html("<em></em>请输入密码，密码长度5~32位");
	});
	$("#AntRegUserPwd_").focus(function(){
		$("#AntRegUserPwd_Tip").show();
		removeC("AntRegUserPwd_Tip");
		$("#AntRegUserPwd_Tip").addClass("o1");
		$("#AntRegUserPwd_Tip").html("<em></em>请再次输入您的密码");
	});
	$("#AntRegUserPwd_").blur(function(){
		checkpassword_();
	});
	$("#AntRegUserPwd").blur(function(){
		checkpassword();
	});
	$("#AntRegUserCode").focus(function(){
		$("#AntRegUserCodeTip").show();
		removeC("AntRegUserCodeTip");
		$("#AntRegUserCodeTip").addClass("o1");
		$("#AntRegUserCodeTip").html("<em></em>请输入图中的验证码");
	});
	$("#AntRegUserCode").blur(function(){
		checkcode("");
	});
	$("#AntRegUserCode2").focus(function(){
		$("#AntRegUserCode2Tip").show();
		removeC("AntRegUserCode2Tip");
		$("#AntRegUserCode2Tip").addClass("o1");
		$("#AntRegUserCode2Tip").html("<em></em>请输入图中的验证码");
	});
	$("#AntRegUserCode2").blur(function(){
		checkcode("2");
	});
	$("#AntRegQuestion").focus(function(){
		$("#AntRegQuestionTip").show();
		removeC("AntRegQuestionTip");
		$("#AntRegQuestionTip").addClass("o1");
		$("#AntRegQuestionTip").html("<em></em>请输入安全验证答案");
	});
	$("#AntRegQuestion").blur(function(){
		checkq();
	});
	$("#AntRegUserEmail").focus(function(){
		$("#AntRegUserEmailTip").show();
		removeC("AntRegUserEmailTip");
		$("#AntRegUserEmailTip").addClass("o1");
		$("#AntRegUserEmailTip").html("<em></em>请输入您的邮箱");
	});
	$("#AntRegUserEmail").blur(function(){
		checkemail();
	});
	
	$("#AntRegUserMobile").focus(function(){
		$("#AntRegUserMobileTip").show();
		removeC("AntRegUserMobileTip");
		$("#AntRegUserMobileTip").addClass("o1");
		$("#AntRegUserMobileTip").html("<em></em>请输入您的手机");
	});
	$("#AntRegUserMobile").blur(function(){
		checkmobile();
	});
	$("#AntRegUserMobilecode").focus(function(){
		$("#AntRegUserMobilecodeTip").show();
		removeC("AntRegUserMobilecodeTip");
		$("#AntRegUserMobilecodeTip").addClass("o1");
		$("#AntRegUserMobilecodeTip").html("<em></em>请输入手机获取的短信激活码");
	});
	$("#AntRegUserMobilecode").blur(function(){
		checkmobilecode();
	});
	
	$("#AntRegUserName").blur(function(){
		checkname();
	});
	
	$("#getmobile").click(function(){
		if(checkmobile())
		{
			getImg();
			$('.pop-cover').css("display","block");		
			$("#vcode").focus();
			$("#vcode").val("");	   
		}
	});
	$('#pop-close').click(function() {
        $('.pop-cover').css("display","none");
    });
	$("#RegForm").submit(function()
	{
		total=0;
		var checklen=5;
		flag=checkname();
		flag=checkpassword();
		flag=checkpassword_();
		var tt = "0";
		var cc=$("input[name='typeid']:checked").val();
		if($("#SiteIsRegisterType").val().indexOf("0") != -1  && $("#SiteIsRegister").val()=="1")
		{
			tt="0";
		}
		else if($("#SiteIsRegisterType").val().indexOf("1") != -1  && $("#SiteIsRegister").val()=="1")
		{
			tt="1";
		}
		else if($("#SiteIsRegisterType").val().indexOf("2") != -1  && $("#SiteIsRegister").val()=="1")
		{
			tt="2";
		}
		if(cc=="0")
		{
			tt="0";	
		}
		else if(cc=="1")
		{
			tt="1";	
		}
		else if(cc=="2")
		{
			tt="2";	
		}
		if( tt == "0" )
		{
			flag=checkemail();
			flag=checkcode("");
			if($("#AntRegQuestion").length>0)
			{
				checklen++;
				checkq();
			}
		}
		else if( tt =="1" )
		{
			flag=checkmobile();
			flag=checkmobilecode();
		}
		else if( tt =="2" )
		{
			flag=checkmobile();
			flag=checkcode("2");
		}
		if(total==checklen)
		{
			login();
		}
		return false;
	});
 });

function checkVerifyCode(){
	sms();
}
function sms()
{
	var str = $.trim($("#AntRegUserMobile").val());
	if(str.len()!=11 && str.len()!=10 ) 
	{
		removeC("AntRegUserMobileTip");
		$("#AntRegUserMobileTip").addClass("o2");
		$("#AntRegUserMobile").focus()
		$("#AntRegUserMobileTip").html("<em></em>请输入您的手机");
		return false;
	}
	var vcode = $.trim($("#vcode").val());
	if(vcode.len()<1)
	{
		alert("请输入验证码");
		$("#vcode").focus();
		getImg();
		return false;
	}
	$("#getmobile").attr("disabled",true);
	$.ajax({
		  url: "/public/ajax.aspx?action=checkname&clientid=AntRegUserMobile1&AntRegUserMobile="+escape(str)+"&AntRegUserCode="+escape(vcode),
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			  if(data!="-99")
			  {
				 $('.pop-cover').css("display","none");
				 if(data=="1"){
					removeC("AntRegUserMobileTip");
					$("#AntRegUserMobileTip").addClass("o3");
					$("#AntRegUserMobileTip").html("<em></em>此手机已被注册，<a href='memberlogin.aspx'>立即登录</a>");
					$("#getmobile").attr("disabled",false);
					return false;
				 }
				 else if(data=="2")
				 {
					removeC("AntRegUserMobileTip");
					$("#AntRegUserMobileTip").addClass("o2");
					$("#AntRegUserMobileTip").html("<em></em>手机格式不正确");
					$("#getmobile").attr("disabled",false);
					return false;
				 }
				 else{
					removeC("AntRegUserMobileTip");
					$("#AntRegUserMobileTip").addClass("o4");
					$("#AntRegUserMobileTip").html("");
					i=120;
					flushtime();
					return false;
				 }
			  }
			  else
			  {
				alert("验证码错误！");
				getImg();
				$("#vcode").val("");
				$("#vcode").focus();
			  }
		  }
	  });	
}
function login()
{
	var tt = "-1";
	var cc=$("input[name='typeid']:checked").val();
	if($("#SiteIsRegisterType").val().indexOf("0") != -1  && $("#SiteIsRegister").val()=="1")
	{
		tt="0";
	}
	else if($("#SiteIsRegisterType").val().indexOf("1") != -1  && $("#SiteIsRegister").val()=="1")
	{
		tt="1";
	}
	else if($("#SiteIsRegisterType").val().indexOf("2") != -1  && $("#SiteIsRegister").val()=="1")
	{
		tt="2";
	}
	if(cc=="0")
	{
		tt="0";	
	}
	else if(cc=="1")
	{
		tt="1";	
	}
	else if(cc=="2")
	{
		tt="2";	
	}
	$("#AntRegSubmit").attr("disabled",true);
	$(".but").removeClass("reg");
	$(".but").addClass("reg_act");
	var curl="/public/ajax.aspx?action=register";
	curl +="&chrname="+escape($("#AntRegUserName").val());
	curl +="&chrpwd="+escape($("#AntRegUserPwd").val());
	if($("#AntRegUserEmail").length>0)
		curl +="&chremail="+escape($("#AntRegUserEmail").val());
	else
		curl +="&chremail=";
	if($("#AntRegUserMobile").length>0)
		curl +="&chrtel="+escape($("#AntRegUserMobile").val());
	else
		curl +="&chrtel=";
	if($("#AntRegUserMobilecode").length>0)
		curl +="&chrqq="+escape($("#AntRegUserMobilecode").val());
	else 
		curl +="&chrqq=";
	if($("#AntRegUserCode").length>0)
		curl +="&chrcode="+escape($("#AntRegUserCode").val());
	else 
		curl +="&chrcode=";
	if($("#AntRegUserCode2").length>0)
		curl +="&chrcode2="+escape($("#AntRegUserCode2").val());
	else 
		curl +="&chrcode2=";
	if($("#AntRegQuestion").length>0)
		curl +="&chrquestion="+escape($("#AntRegQuestion").val());
	else 
		curl +="&chrquestion=";
	curl +="&tt="+tt;
	$.ajax({
		  url: curl,
		  cache: false,
		  async:false, 
		  success:function(data)
		  {
			   if(data=="1")
			  {
				  if(window.location.href.toLowerCase().indexOf(".26.ca")!=-1)
				  {
						WebLoginCheck($("#AntRegUserName").val(),$("#AntRegUserPwd").val(),"","");
						setTimeout('RegisterOverState()',1000)
				  }
				  else
				  {
			  	      window.location.href="MemberSuccess.aspx";
				  }
			  }
			  else if(data=="2")
			  {
					window.location.href="MemberWait.aspx?str1="+escape($("#AntRegUserName").val());
			  }
			  else
			  {
				  if(data.indexOf("2,")!=-1)
				  {
					  data=data.replace("2,","");
					  window.location.href="MemberEmail.aspx?str1="+escape($("#AntRegUserEmail").val())+"&str2="+data+"&str3="+escape($("#AntRegUserName").val());
				  }
				  else
				  {
					 alert(data);
					 $(".but").removeClass("reg_act");
					 $(".but").addClass("reg");
					 $("#AntRegSubmit").attr("disabled",false);
				  }
			  }
			
		  }
	});	
	return false;
}
function RegisterOverState()
{
	window.location.href="MemberSuccess.aspx";
}
function WebLoginCheck(username,userpwd,usercode,remeber)
{
	var gourl="http://26.ca/public/ajax.aspx?action=login&script=1";
	gourl +="&chrname="+escape(username);
	gourl +="&chrpwd="+escape(userpwd);
	gourl +="&chrcode="+escape(usercode);
	gourl +="&flag="+escape(remeber);
	gourl +="&time="+new Date();
	var   fr=document.createElement("IFRAME")   
	fr.height=0;   
	fr.width=0   
	fr.src=gourl;  
	document.body.appendChild(fr) ;
}
function settypeid(tt)
{
	if(tt==0)
	{
		$("#mobile1").hide();	
		$("#mobile2").hide();	
		$("#mobile3").show();	
		$("#mobile4").show();	
		$("#mobile5").show();	
		$("#mobile6").hide();
		$("#emailcode").attr("src",'../VerifyCode/VerifyCode.aspx?key=1&tt='+Math.random());
	}
	else if(tt==1)
	{
		$("#mobile1").show();	
		$("#mobile2").show();	
		$("#mobile3").hide();	
		$("#mobile4").hide();	
		$("#mobile5").hide();
		$("#mobile6").hide();
	}
	else if(tt==2)
	{
		$("#mobile1").show();
		$("#mobile2").hide();	
		$("#mobile3").hide();	
		$("#mobile4").hide();	
		$("#mobile5").hide();
		$("#mobile6").show();
		$("#mobilecode").attr("src",'../VerifyCode/VerifyCode.aspx?key=1&tt='+Math.random());	
	}
}
String.prototype.len   =   function(){return   this.replace(/[^\x00-\xff]/g, "**").length;}
function removeC(obj)
{
	$("#"+obj).show();
	$("#"+obj).removeClass("o1");
	$("#"+obj).removeClass("o2");
	$("#"+obj).removeClass("o3");
	$("#"+obj).removeClass("o4");
}
//判断输入密码的类型  
function CharMode(iN){  
	 if (iN >= 48 && iN <= 57) //数字 
		return 1;
	if (iN >= 65 && iN <= 90) //大写字母 
		return 2;
	if (iN >= 97 && iN <= 122) //小写 
		return 4;
	else
		return 8; //特殊字符  
}  
//bitTotal函数  
//计算密码模式  
function bitTotal(num){  
	modes = 0;
	for (i = 0; i < 4; i++) {
		if (num & 1) modes++;
		num >>>= 1;
	}
	return modes;
}  
//返回强度级别  
function checkStrong(sPW){  
	$(".pwd").removeClass("pw-1");
	$(".pwd").removeClass("pw-2");
	$(".pwd").removeClass("pw-3");
	Modes = 0; //输入的字符种类有几种如：a1两种aA_d三种
	for (i = 0; i < sPW.length; i++) {
		//测试每一个字符的类别并统计一共有多少种模式. 
		Modes |= CharMode(sPW.charCodeAt(i));
	}
	Modes = bitTotal(Modes); //由几种字符组成
	var pwdLength = sPW.length; //密码长度
	var level = 0; //密码强度级别
	if (pwdLength < 5 && Modes <= 2)
		level = 0;
	if ((pwdLength < 8 && Modes >= 3) || (pwdLength >= 8 && Modes == 2))
		level = 1;
	if (pwdLength >= 10 && Modes >= 3)
		level = 2;
	return level;
}  