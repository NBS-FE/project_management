$(function(){
	$("#wi ul").children().hover(function(){
		$("#wi ul").children().removeClass("on");
		$(this).addClass("on");
		})
 	 $("#wi ul li:first-child").addClass("on");
	
	//幻灯
	jQuery(".wide-focus").slide({ titCell:".num li", mainCell:".pic",effect:"fold", autoPlay:true,trigger:"click",
	startFun:function(i){jQuery(".wide-focus .txt li").eq(i).animate({"bottom":0}).siblings().animate({"bottom":-40});}});
	//商城频道箭头控制图片滚动
	jQuery(".wide-picScroll").slide({ mainCell:"ul",autoPlay:true,effect:"left", vis:7, scroll:1, autoPage:true, pnLoop:false });
	jQuery(".wide-picScroll-2").slide({ mainCell:".ul1",autoPlay:true,effect:"left", vis:2, scroll:1, autoPage:true, pnLoop:false });
	jQuery(".wide-picScroll-2").slide({ mainCell:".ul2",autoPlay:true,effect:"left", vis:2, scroll:1, autoPage:true, pnLoop:false });

	jQuery(".wide-picScroll-3").slide({ mainCell:"ul",autoPlay:true,effect:"left", vis:2, scroll:1, autoPage:true, pnLoop:false });
	//切换，选择分类	
	jQuery(".wide-info-tab").slide();
	//向上滚动
	jQuery(".c5-right").slide({mainCell:".bd ul",autoPage:true,effect:"topLoop",autoPlay:true,vis:3});
});

//微信

/*左侧导航的显示与隐藏*/
$(function(){
       $(".qnav-2 ul li").hover(function() {
		   $("#nav-content").find(".nav-main").eq($(this).index()).show();
       }, function() {
		$("#nav-content").find(".nav-main").eq($(this).index()).hide();
      });
       $("#nav-content .nav-main").hover(function() {
          $(".qnav-2 ul").find("li").eq($(this).index()).addClass("bjs");
            $(this).show();
       }, function() {
		   $(".qnav-2 ul").find("li").eq($(this).index()).removeClass("bjs");
           $(this).hide();
       });
   })
/*分类信息的切换*/
$(function(){
	$(".c1-title1 ul li").each(function(i) {
       $(this).hover(function(){
		   $(this).addClass("d2").siblings().removeClass("d2");
		   $(".con:eq("+i+")").show().siblings(".con").hide();
	 }) 
}) 
});
/*商城频道的切换*/
$(function(){
	$(".c4-title1 ul li").each(function(i) {
       $(this).hover(function(){
		   $(this).addClass("d2").siblings().removeClass("d2");
		   $(".c4:eq("+i+")").show().siblings(".c4").hide();
	 }) 
}) 
});
//出售房源
$(function(){
	$(".hd ul li").each(function(i) {
       $(this).hover(function(){
		   $(this).addClass("d12").siblings().removeClass("d12");
		   $(".cs:eq("+i+")").show().siblings(".cs").hide();
	 }) 
}) 
});



//幻灯片
$(function(){
          var index = 0;
          var picTimer;
          var sWidth = $(".Lb_flash").width();
          var len = $(".Lb_flash ul li").length; //获取焦点图个数
          $(".Lb_flash ul").css("width",sWidth * (len));
          //显示图片函数，根据接收的index值显示相应的内容
          //为小按钮添加鼠标滑入事件，以显示相应的内容
	     $(".Lb_z_l span a").mouseover(function() {
		    index = $(".Lb_z_l span a").index(this);
		    showPics(index);
	     }).eq( len-4 ).trigger("mouseover");
		 //鼠标滑上焦点图时停止自动播放，滑出时开始自动播放
        $(".Lb_flash").hover(function() {
	        clearInterval(picTimer);
        },function() {
	        picTimer = setInterval(function() {
		        showPics(index);
		        index++;
		        if(index == len) {index = 0;}
	        },4000); //此4000代表自动播放的间隔，单位：毫秒
        }).trigger("mouseleave");
		
});

		
	      function showPics(index) { //普通切换
		     var nowLeft = -index*sWidth; //根据index值计算ul元素的left值
		     $(".Lb_flash ul").stop(true,false).animate({"left":nowLeft},300); //通过animate()调整ul元素滚动到计算出的position
			 $(".Lb_z_l span a").removeClass("om").eq(index).addClass("om"); 
		    $(".Lb_z_l span a").stop(true,false).animate({"opacity":"0.4"},300).eq(index).stop(true,false).animate({"opacity":"1"},300);//为当前的按钮切换到选中的效果
	      }




















