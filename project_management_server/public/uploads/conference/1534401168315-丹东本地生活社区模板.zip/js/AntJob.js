﻿var userMenuTimeOut,userMenuTimeOut1,userMenuTimeOut2;
jQuery(function($){
	$("#CityClick").click(function(){
		$(".AntCityLay").fadeIn();		   
	},function(){
		var menuHide = function(){
			$(".AntCityLay").fadeOut();
		};
		userMenuTimeOut = setTimeout(menuHide,500);
	});
	$(".AntCityLay").hover(function(){
		clearTimeout(userMenuTimeOut);
	},function(){
		$(this).fadeOut();
	});
	$("#XueliNavparent").click(function(){ //鼠标移动函数
		 $('div#txtXueliNav').fadeIn();  //找到ul.son_ul显示
	});
	$("#XueliNavparent").hover(function(){ //鼠标移动函数
	},function(){
		$("div#txtXueliNav").fadeOut(); 
	});
	$("#jingyanNavparent").click(function(){ //鼠标移动函数
		 $('div#txtjingyanNav').fadeIn();  //找到ul.son_ul显示
	});
	$("#jingyanNavparent").hover(function(){ //鼠标移动函数
	},function(){
		$("div#txtjingyanNav").fadeOut(); 
	});
	$("#CatNavparent").click(function(){ //鼠标移动函数
		 $('div#txtCatNav').fadeIn();  //找到ul.son_ul显示
	});
	$("#JobAccountUserpwd").blur(function(){
		if($(this).val()==''){$('.userpwdtop').show();}
	});
	$("#CatNavparent").hover(function(){ //鼠标移动函数
	},function(){
		$("div#txtCatNav").fadeOut(); 
	});
	var oldid1,oldid2;
	$("#txtjingyanNav li a").click(function(){
		 $("#hiddenjingyan").val($(this).attr("rel"));
		 $("#txtjingyan").val($(this).html());
		 $(oldid1).removeClass("current");
		 oldid1=$(this)
		 $(this).addClass("current");
	 });
	$("#txtXueliNav li a").click(function(){
		 $("#hiddenXueli").val($(this).attr("rel"));
		 $("#txtXueli").val($(this).html());
		 $(this).addClass("current");
		 $(oldid2).removeClass("current");
		 oldid2=$(this)
	 });
	$("#txtCatNav li a").click(function(){
		 $("#hiddenloc").val($(this).attr("rel"));
		 $("#txtLoc").val($(this).html());
		 $(this).addClass("current");
		 $(oldid2).removeClass("current");
		 oldid2=$(this)
	 });
	notice_setscool();
	Company_setscool();
	var now = new Date(),hour = now.getHours() 
	if(hour < 6){$("#AntHours").html("凌晨好！")} 
	else if (hour < 9){$("#AntHours").html("早上好！")} 
	else if (hour < 12){$("#AntHours").html("上午好！")} 
	else if (hour < 14){$("#AntHours").html("中午好！")} 
	else if (hour < 17){$("#AntHours").html("下午好！")} 
	else if (hour < 19){$("#AntHours").html("傍晚好！")} 
	else if (hour < 22){$("#AntHours").html("晚上好！")} 
	else {$("#AntHours").html("夜里好！")};
	$("#AntJobLoginForm").submit(function(){
		var username = $.trim($("#JobAccountUsername").val());							   
		var userpwd = $.trim($("#JobAccountUserpwd").val());
		if(username.length==0)
		{
			alert("对不起，请输入您的用户名！");
			$("#JobAccountUsername").focus();
			return false;
		}	
		if(userpwd.length==0)
		{
			alert("对不起，请输入您的密码！");
			$("#JobAccountUserpwd").focus();
			return false;
		}
		var tt="";
		
		$("#JobAccountButton").attr("disabled", true); //设置为不可点
		AntLoginUsers(username,userpwd,"",tt,6);
		return false;							
	});
	$("#AccountReg,#AccountCompanyReg").click(function(){
		CreateCookie("oldsubmit","");
		ShowDailog('用户注册',300,200,'JobRegister.aspx?key='+$(this).attr("rel"),'true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');		
		return false;
	});
	$(".Exit-1,.Exit").click(function(){
		ShowDailog('退出登录',300,200,'JobLoginOut.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');	
		return false;
	});
	if($_D("JobDialogRegister")){
		$("#RegVerifyCode").css("cursor","pointer");
		$("#RegVerifyCode").click(function(){ 
			$("#RegVerifyCode").attr("src","../VerifyCode/VerifyCode.aspx?key=1&tt="+Math.random());			  
		});	
		$.formValidator.initConfig({formid:"JobDialogRegister",errorfocus:false,onerror:function(msg){},onsuccess:function(){AntRegesterUsers(3);return false;}});
		$.formValidator.getInitConfig("1").wideword = true;
		$("#AntRegUserName").formValidator({onshow:"3-15个字符，可为汉字。",onfocus:"3-15个字符，可为汉字。",oncorrect:"&nbsp;"}).inputValidator({min:3,max:15,onerror:"会员名在3-15个字符。"})
		.ajaxValidator({
			url : "../public/ajax.aspx?action=checkname",
			cache: false,
			dataType:'text',
			success:function(data)
			{
				if( data == "0" )
				{
					 return true;
				}
				else
				{
					return false;
				}
			},
			buttons: $("#AntRegSubmit"),
			error: function(){alert("服务器没有返回数据，可能服务器忙，请重试");},
			onerror : "该会员名已被使用。",
			onwait : "正在检验用户名，请稍候..."
		});
		$("#AntRegUserPwd").formValidator({onshow:"密码长度6~32位。",onfocus:"密码长度6~32位。",oncorrect:"&nbsp;"}).inputValidator({min:6,empty:{leftempty:false,rightempty:false,emptyerror:"密码两边不能有空符号。"},onerror:"密码长度6~32位,请确认。"});
		$("#AntRegUserPwd_").formValidator({onshow:"请再次输入密码。",onfocus:"请再次输入密码。",oncorrect:"&nbsp;"}).inputValidator({min:6,empty:{leftempty:false,rightempty:false,emptyerror:"重复密码两边不能有空符号。"},onerror:"重复密码密码长度6~32位。"}).compareValidator({desid:"AntRegUserPwd",operateor:"=",onerror:"两次输入的密码不一致。"});
		$("#AntRegUserEmail").formValidator({onshow:"请输入您常用的邮箱。",onfocus:"请输入您常用的邮箱。",oncorrect:"&nbsp;",defaultvalue:"@"}).inputValidator({min:6,max:100,onerror:"请输入正确格式的邮箱。"}).regexValidator({regexp:"^([\\w-.]+)@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.)|(([\\w-]+.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(]?)$",onerror:"请输入正确格式的邮箱"})
		.ajaxValidator({
			url : "../public/ajax.aspx?action=checkname",
			cache: false,
			dataType:'text',
			success:function(data)
			{
				if( data == "0" )
				{
					 return true;
				}
				else
				{
					return false;
				}
			},
			buttons: $("#AntRegSubmit"),
			error: function(){alert("服务器没有返回数据，可能服务器忙，请重试");},
			onerror : "该电子邮件已被使用。",
			onwait : "正在检验电子邮件，请稍候..."
		});
		$("#AntRegUserMobile").formValidator({empty:true,onshow:"输入手机号码可享受更多服务。",onfocus:"请输入你的手机号码。",oncorrect:"&nbsp;",onempty:" "}).inputValidator({min:11,max:11,onerror:"手机号码必须是11位的。"}).regexValidator({regexp:"mobile",datatype:"enum",onerror:"输入的手机号码格式不正确"});
		$("#AntRegUserQQ").formValidator({empty:true,onshow:"输入您常用的QQ号码。",onfocus:"QQ号码可以为空。",oncorrect:"&nbsp;",onempty:" "}).regexValidator({regexp:"^\\d{5,10}$",onerror:"QQ号码格式不正确。"});
		$("#AntRegUserCode").formValidator({onshow:"请输入左侧的验证码。",onfocus:"请正确输入验证码。",oncorrect:"&nbsp;"}).inputValidator({min:1,max:20,onerror:"验证码不能为空。"})
		$("#AntRegQuestion").formValidator({onshow:"请输入安全验证答案。",onfocus:"输入安全验证答案。",oncorrect:"&nbsp;"}).inputValidator({min:1,max:20,onerror:"验证答案不能为空。"})
	}
	$("#txtKeywords,#txtjobtopKeyword").focus(function(){
		if($.trim(this.value) == "结果中包含该关键词")
			this.value = "";
	}).blur(function(){
		if($.trim(this.value) == "")
			this.value = "结果中包含该关键词";	
	});
	$('#fontSmall').click(function(){
		$('#NewsContent').css({'font-size':'14px'});
		$("#fontSmall").css({'color':'#666'});
		$("#fontBig").css({'color':'#0B3B8C'});
	});
	$('#fontBig').click(function(){
		$('#NewsContent').css({'font-size':'16px'});
		$("#fontSmall").css({'color':'#0B3B8C'});
		$("#fontBig").css({'color':'#666'});
	});
	$('#headcheckbox').click(function(){
		$("input[name=subBox]:checkbox").attr("checked",this.checked); 
		$("input[name=subBox]:checkbox").each(function(){
			if(this.checked)
			{
				$(this).parent().parent().parent().parent().addClass("current");
			}
			else
			{
				$(this).parent().parent().parent().parent().removeClass("current");
			}
		});
		/*$("#Work-ListInfo").find("#checkbox").each(function(){
			if( $("#headcheckbox").attr("checked")=="checked")
			{
				$(this).parent().parent().parent().parent().addClass("current");
				$(this).attr("checked",true);
			}
			else	
			{
				$(this).parent().parent().parent().parent().removeClass("current");
				$(this).removeAttr("checked");
			}
		});	*/												 
	 });
	$("#Work-ListInfo").find("input[name=subBox]:checkbox").each(function(){
		$(this).click(function(){
			if(this.checked)
			{
				$(this).parent().parent().parent().parent().addClass("current");
				$(this).attr("checked",true);
			}
			else	
			{
				$(this).parent().parent().parent().parent().removeClass("current");
				$(this).removeAttr("checked");
			}	
		});	
	});															
	$("#Work-ListInfo").find("#ApplyInfo").each(function(){
		$(this).click(function(){
			 var aa = $(this).attr("rel");
			 $.ajax({
			  url: "../public/ajax.aspx?action=CheckIsLogin",
			  cache: false,
			  success:function(data)
			  {
				  if(data==-1)
				  {
					 CreateCookie("oldsubmit","applyjobinfo"+aa );
					 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
					 return false;
				  }
				  else{
					 JobInfoApply( aa );
				  }
			  }
			});
			return false;
		});
	});
	$("#applycheckbox").click(function(){
		var allid="";
		$("#Work-ListInfo").find("input[name=subBox]:checkbox").each(function(){
			if(this.checked)
			{
				if( allid.length>0 )
					allid +=",";	
				allid +=$(this).val();
			}
		});	
		if(allid=="")
		{
			alert("请选择您要申请的职位！");
			return false;
		}
		else
		{
			$.ajax({
			  url: "../public/ajax.aspx?action=CheckIsLogin",
			  cache: false,
			  success:function(data)
			  {
				  if(data==-1)
				  {
					 CreateCookie("oldsubmit","applyjobinfo"+allid );
					 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
					 return false;
				  }
				  else{
					 JobInfoApply( allid );
				  }
			  }
			});
			return false;
		}
	});	
	$("#liulancheckbox").click(function(){
		var allid="";
		$("#Work-ListInfo").find("input[name=subBox]:checkbox").each(function(){
			if(this.checked)
			{
				if( allid.length>0 )
					allid +=",";	
				allid +=$(this).val();
			}
		});	
		if(allid=="")
		{
			alert("请选择您要浏览的职位！");
			return false;
		}
		else
		{
			var aa=$("#jobhiddenvalue").val();
			var bb=aa.split(",");
			var url="JobInfo.aspx?id="+allid;
			if(bb[0]=="0")
				var url=encodeURIComponent("JobInfo-"+allid+bb[1]);
			window.open(url,"_blank");
			return false;
		}
	});	
	$("#favcheckbox").click(function(){
		var allid="";
		$("#Work-ListInfo").find("input[name=subBox]:checkbox").each(function(){
			if(this.checked)
			{
				if( allid.length>0 )
					allid +=",";	
				allid +=$(this).val();
			}
		});	
		if(allid=="")
		{
			alert("请选择您要收藏的职位！");
			return false;
		}
		else
		{
			$.ajax({
			  url: "../public/ajax.aspx?action=CheckIsLogin",
			  cache: false,
			  success:function(data)
			  {
				  if(data==-1)
				  {
					 CreateCookie("oldsubmit","favjobinfo"+allid);
					 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
					 return false;
				  }
				  else{
					 JobInfoFav(allid);
				  }
			  }
			});
			return false;
		}
	});	
	$(".AntJobListings").find("ul li").each(function(){
		$(this).click(function(){
			var obj=$(this);
			$(".AntJobListings").find("ul li").each(function(){
				$(this).removeClass("li");	
				$(this).find(":checkbox").attr("checked",false);
			});		
			obj.addClass("li");
			obj.find(":checkbox").attr("checked",true);
			$(".AntBasicInfo").html( "<img src='"+$(".AntBasicInfo").attr("rel")+"' style='margin:20px;'>" );
			$.ajax({
			  url: "ShowAjaxJobInfo.aspx?id="+obj.find(":checkbox").val(),
			  cache: false,
			  success:function(data)
			  {
				  $(".AntBasicInfo").html(data);
				  LoadMap();
			  }
			});	
		});							   
	});	
	LoadMap();		//载入地图				
	$("#AntTopSearchForm").submit(function(){
		var loc=$.trim($("#hiddenloc").val());
		var jingyan=$.trim($("#hiddenjingyan").val());
		var xueli=$.trim($("#hiddenXueli").val());
		var Keyword=$.trim($("#txtjobtopKeyword").val());
		var aa=$("#jobhiddenvalue").val();
		var bb=aa.split(",");
		if(Keyword=="结果中包含该关键词")
		{
			Keyword="";
		}
		if(loc.length==0 && jingyan.length==0  && xueli.length==0  && Keyword.length==0){
			var url="SearchJob.aspx";
			if(bb[0]=="0")
				var url=encodeURIComponent("SearchJob"+bb[1]);
			window.open(url,"_self");
			return false;
		}
		if(xueli.length==0)
			xueli="0";
		if(jingyan.length==0)
			jingyan="0";
		var url="SearchJob.aspx?loc="+loc+"&jingyan="+jingyan+"&xueli="+xueli+"&Keyword="+escape(Keyword);
		if(bb[0]=="0")
			var url=encodeURIComponent("SearchJob-"+loc+"-"+jingyan+"-"+xueli+"-0-A"+Keyword+"A-p0"+bb[1]);
		window.open(url,"_self");
		return false;
	});
	$("#AntTopResumeForm").submit(function(){
		var loc=$.trim($("#hiddenloc").val());
		var cat=$.trim($("#hiddencat").val());
		var ind=$.trim($("#hiddenind").val());
		var jingyan=$.trim($("#hiddenjingyan").val());
		var xueli=$.trim($("#hiddenXueli").val());
		var Keyword=$.trim($("#txtjobtopKeyword").val());
		var aa=$("#jobhiddenvalue").val();
		var bb=aa.split(",");
		if(Keyword=="结果中包含该关键词")
		{
			Keyword="";
		}
		if(loc.length==0 && cat.length==0 && ind.length==0 && jingyan.length==0  && xueli.length==0  && Keyword.length==0){
			var url="ResumeIndex.aspx";
			if(bb[0]=="0")
				var url=encodeURIComponent("ResumeIndex"+bb[1]);
			window.open(url,"_self");
			return false;
		}
		if(xueli.length==0)
			xueli="0";
		if(jingyan.length==0)
			jingyan="0";
		var url="ResumeIndex.aspx?cat="+escape(cat)+"&ind="+ind+"&loc="+loc+"&jingyan="+jingyan+"&xueli="+xueli+"&Keyword="+escape(Keyword);
		if(bb[0]=="0")
			var url=encodeURIComponent("ResumeIndex-"+cat+"-"+ind+"-"+loc+"-"+jingyan+"-"+xueli+"-0-B"+Keyword+"B-p0"+bb[1]);
		window.open(url,"_self");
		return false;
	});									   
	$("#jobindexform").submit(function(){
		var loc=$.trim($("#hiddenloc").val());
		var jingyan=$.trim($("#hiddenjingyan").val());
		var xueli=$.trim($("#hiddenXueli").val());
		var cat="";
		var ind="";
		var Keyword=$.trim($("#txtKeywords").val());
		var aa=$("#jobhiddenvalue").val();
		var bb=aa.split(",");
		if(Keyword=="结果中包含该关键词")
		{
			Keyword="";
		}
		if(loc.length==0 && cat.length==0 && ind.length==0 && jingyan.length==0  && xueli.length==0  && Keyword.length==0){
			var url="SearchJob.aspx";
			if(bb[0]=="0")
				var url=encodeURIComponent("SearchJob"+bb[1]);
			window.open(url,"_blank");
			return false;
		}
		if(xueli.length==0)
			xueli="0";
		if(jingyan.length==0)
			jingyan="0";
		var url="SearchJob.aspx?cat="+escape(loc)+"&jingyan="+jingyan+"&xueli="+xueli+"&Keyword="+escape(Keyword);
		if(bb[0]=="0")
			var url=encodeURIComponent("SearchJob-"+loc+"-"+jingyan+"-"+xueli+"-0-A"+Keyword+"A-p0"+bb[1]);
		window.open(url,"_blank");
		return false;
	});
	$("#AntHrList").find("input[name=checkbox]:checkbox").each(function(){
		$(this).click(function(){
			if(this.checked)
			{
				$(this).parent().parent().parent().parent().addClass("current");
				$(this).attr("checked",true);
			}
			else	
			{
				$(this).parent().parent().parent().parent().removeClass("current");
				$(this).removeAttr("checked");
			}	
		});	
	});	
	$('#headJobcheckbox').click(function(){
		$("input[name=checkbox]:checkbox").attr("checked",this.checked); 
		$("input[name=checkbox]:checkbox").each(function(){
			if(this.checked)
			{
				$(this).parent().parent().parent().parent().addClass("current");
			}
			else
			{
				$(this).parent().parent().parent().parent().removeClass("current");
			}
		});
		/*$("#AntHrList").find("#checkbox").each(function(){
			if( $("#headJobcheckbox").attr("checked")==true)
			{
				$(this).parent().parent().parent().parent().addClass("current");
				$(this).attr("checked",true);
			}
			else	
			{
				$(this).parent().parent().parent().parent().removeClass("current");
				$(this).removeAttr("checked");
			}
		});	*/												 
	 });
	$("#ResumeReview,#ResumeBottomReview").click(function(){
		var allid="";
		$("#AntHrList").find("input[name=checkbox]:checkbox").each(function(){
			if(this.checked)
			{
				if( allid.length>0 )
					allid +=",";	
				allid +=$(this).val();
			}
		});	
		if(allid=="")
		{
			alert("请选择您要浏览的简历！");
			return false;
		}
		else
		{
			var aa=$("#jobhiddenvalue").val();
			var bb=aa.split(",");
			var url="ResumePreview.aspx?id="+allid;
			if(bb[0]=="0")
				var url=encodeURIComponent("ResumePreview-"+allid+bb[1]);
			window.open(url,"_blank");
			return false;
		}
	});	
	$("#ResumeFav,#BottomResumeFav").click(function(){
		var allid="";
		$("#AntHrList").find("input[name=checkbox]:checkbox").each(function(){
			if(this.checked)
			{
				if( allid.length>0 )
					allid +=",";	
				allid +=$(this).val();
			}
		});	
		if(allid=="")
		{
			alert("请选择您要收藏的人才简历！");
			return false;
		}
		else
		{
			$.ajax({
			  url: "../public/ajax.aspx?action=CheckIsLogin",
			  cache: false,
			  success:function(data)
			  {
				  if(data==-1)
				  {
					 CreateCookie("oldsubmit","favresumeinfo"+allid);
					 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
					 return false;
				  }
				  else{
					 JobResumeFav(allid);
				  }
			  }
			});
			return false;
		}
	});	
	$("#fadetab_id").find("a").each(function(){
		$(this).click(function(){
			var obj=$(this);
			$("#fadetab_id").find("li").each(function(){
				$(this).removeClass("cur");	
			});		
			obj.parent().addClass("cur");
			$("#resumecontent").html( "<img src='"+$("#resumecontent").attr("rel")+"' style='margin:20px;'>" );
			$.ajax({
			  url: "ShowAjaxJobResume.aspx?id="+obj.attr("rel"),
			  cache: false,
			  success:function(data)
			  {
				  $("#hiddenresume").val(obj.attr("rel"))
				  $("#resumecontent").html(data);
				  LoadResume();
				  $("#Ant-Published,#Ant-Publishedbottom").click(function(){
					CheckFabu();
					return false;
				 });
			  }
			});	
		});							   
	});	
	if($("#fadetab_id").length>0)
	{
		var newSlider = new slider(60,100);
		newSlider.register("fadetab_id","aSliderPre","aSliderNext","aSliderHead","aSliderEnd");
	}
	var urlnum = window.location.href.indexOf("#jobapply");
	if( urlnum !=-1){
		var y=$("#InfoApply").offset().top ;
		$(document.documentElement).animate({"scrollTop": y}, {duration:"slow"});
	}
	urlnum = window.location.href.indexOf("#resumeapply");
	if( urlnum !=-1){
		var y=$("#Ant-Invite").offset().top ;
		$(document.documentElement).animate({"scrollTop": y}, {duration:"slow"});
	}
	
	LoadResume();	
	
	$("#Ant-Published,#Ant-Publishedbottom").click(function(){
		CheckFabu();
		return false;
	});
	$(".lb_autoWid li").find("img").mouseover(function(){
		if($(this).parent("a").next(".autoWid").length>0)
		{
			var wi = $(this).width();
			var hei = $(this).height();
			$(this).parent("a").next(".autoWid").width(wi).show();
			$(this).parents("li").css("z-index","500");
			$(".autoWid").css("top", hei + "px");
			$(this).css("background","#65A9E6");
		}
	})
	$(".lb_autoWid li").find("embed").mouseover(function(){
		if($(this).next(".autoWid").length>0)
		{
			var wi = $(this).width();
			var hei = $(this).height();
			$(this).next(".autoWid").width(wi).show();
			$(this).parents("li").css("z-index","500");
			$(".autoWid").css("top", hei + "px");
			$(this).css("background","#65A9E6");
		}
	})
	$(".lb_autoWid li").mouseleave(function(){
		$(this).children(".autoWid").hide();
		$(this).css("z-index","100");
		$(".lb_autoWid li img").css("background","#fff")
		$(".lb_autoWid li embed").css("background","#fff")
	})
});
function CheckFabu()
{
	$.ajax({
	  url: "../public/ajax.aspx?action=CheckLoginStyle",
	  cache: false,
	  success:function(data)
	  {
		  if(data==-1)
		  {
			 CreateCookie("oldsubmit","fabu" );
			 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
			 return false;
		  }
		  
		  else{
			   try{closeopendiv();}catch(err){}
			   window.open(SiteWebUrl+"Account/MemberJobInfoAdd.aspx","_blank");
		  }
	  }
	});	
}
function EditJobWord(aa)
{
	ShowDailog('管理信息',300,200,'JobEdit.aspx?id='+aa,'true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');		
}
function LoadResume()
{
	$("#Ant-Favorites,#Ant-Favoritesbottom").click(function(){
		var allid= $(this).attr("rel");
		$.ajax({
		  url: "../public/ajax.aspx?action=CheckIsLogin",
		  cache: false,
		  success:function(data)
		  {
			  if(data==-1)
			  {
				 CreateCookie("oldsubmit","favresumeinfo"+allid);
				 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
				 return false;
			  }
			  else{
				 JobResumeFav(allid);
			  }
		  }
		});
		return false;					   
	});
	$("#resumelogin,#resumeloginbottom").click(function(){
		CreateCookie("oldsubmit","");
		ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');		
		return false;
	});
	$("#resumeregister,#resumeregisterbottom").click(function(){
		CreateCookie("oldsubmit","");
		window.location.href=SiteWebUrl+'account/reg.html?from='+escape(window.location.href);
		//ShowDailog('用户注册',300,200,'JobRegister.aspx?key=1','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');		
		return false;
	});
	$("#resumelook,#resumelookbottom").click(function(){
		if(confirm("您确定要查看吗？"))
		{
			$.ajax({
			  url: "../public/ajax.aspx?action=payresumeinfo&id="+$(this).attr("rel"),
			  cache: false,
			  success:function(data)
			  {
				  if(data==0)
				  {
					 window.location.href=window.location.href;
				  }
				  else{
					 alert(data);
				  }
			  }
			});
		}
		return false;
	});
	$("#Ant-Invitebottom,#Ant-Invite").click(function(){
		ShowDailog('面试邀请通知',300,200,'ResumeApply.aspx?id='+$(this).attr("rel"),'true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');		
		return false;
	});
	$("#searchjobkeyword").focus(function(){
		if($.trim(this.value) == "请输入搜索关键字！")
			this.value = "";
	}).blur(function(){
		if($.trim(this.value) == "")
			this.value = "请输入搜索关键字！";												  
	});
	$("#jobtopselectform").submit(function(){
		var searchflag=false;
		if($.trim($("#searchjobkeyword").val()) != "请输入搜索关键字！"  && $.trim($("#searchjobkeyword").val()) !="")								 
		{
			searchflag=true;
		}
		else{
			$("#searchjobkeyword").val("");
		}
		var cc=$("#HouseTopSelected").val();
		var aa=$("#jobhiddenvalue").val();
		var bb=aa.split(",");
		if(searchflag){
			var url="SearchJob.aspx?SearchKeyword="+escape($("#searchjobkeyword").val());
			if(bb[0]=="0")
				var url=encodeURIComponent("SearchJob--0-0-0-A"+$("#searchjobkeyword").val()+"A-p0"+bb[1]);
			if(cc=="1")
			{
				url="ResumeIndex.aspx?SearchKeyword="+escape($("#searchjobkeyword").val());
				if(bb[0]=="0")
					url=encodeURIComponent("ResumeIndex--0-0-0-B"+$("#searchjobkeyword").val()+"B-p0"+bb[1]);
			}
			window.open(url,"_self");
			return false;	
		}
		else{
			var url="SearchJob.aspx";
			if(bb[0]=="0")
				var url=encodeURIComponent("SearchJob"+bb[1]);
			if(cc=="1")
			{
				url="ResumeIndex.aspx";
				if(bb[0]=="0")
					url=encodeURIComponent("ResumeIndex"+bb[1]);
			}
			window.open(url,"_self");
			return false;
		}
		return false;							  
	});
}
function JobResumeFav(allid)
{
	$.ajax({
	  url: "../public/ajax.aspx?action=resumefav&id="+allid,
	  cache: false,
	  success:function(data)
	  {
		  if(data=="0")
		  {	
			 try{closeopendiv();}catch(err){}
			 alert("恭喜您，人才简历收藏成功！");	
		  }
		  else if(data.indexOf("完善")!=-1)
		  {
			  try{closeopendiv();}catch(err){}
			  alert(data);
			  window.location.href=SiteWebUrl+"account/MemberCompany.aspx";
		  }
		  else{
			  try{closeopendiv();}catch(err){}
			  alert(data);
		  }
	  }
	});	
}
function LoadMap()
{
	var  dia=null;
	$("#companymap").css("cursor","pointer")
	$("#companymap").click(function(){
		if(!dia){
			dia = new $.dialog({
			closeButton:true,
			width:750,
			overlay:true
			}).setHeader('<h4>查看公司地图</h4>')
			.setBody('<iframe frameborder="0" scrolling="no" style="height:440px; width:730px;" src="CompanyMap.aspx?id='+$(this).attr("rel")+'" ></iframe>')
			.show();
		}
		else{
			dia.show();
		}
		return false;			
	});		
}
function InfoApplyaDD(aa)
{
	$.ajax({
	  url: "../public/ajax.aspx?action=CheckIsLogin",
	  cache: false,
	  success:function(data)
	  {
		  if(data==-1)
		  {
			 CreateCookie("oldsubmit","applyjobinfo"+aa );
			 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
			 return false;
		  }
		  else{
			 JobInfoApply( aa );
		  }
	  }
	});
	return false;
}
function addfavorts(aa)
{
	$.ajax({
	  url: "../public/ajax.aspx?action=CheckIsLogin",
	  cache: false,
	  success:function(data)
	  {
		  if(data==-1)
		  {
			 CreateCookie("oldsubmit","favjobinfo"+aa );
			 ShowDailog('用户登录',300,200,'JobLogin.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
			 return false;
		  }
		  else{
			 JobInfoFav( aa );
		  }
	  }
	});
	return false;
}
function JobInfoApply(allid)
{
	$.ajax({
	  url: "../public/ajax.aspx?action=jobapply&id="+allid,
	  cache: false,
	  success:function(data)
	  {
		  if(data=="0")
		  {	
			  if($("#AntMessageBoxFrame").length >0 )
			  {
				  $("#AntMessageBoxFrame").attr("src","JobAply.aspx") 
			  }
			  else{
				  ShowDailog('申请职位',300,200,'JobAply.aspx','true','AntJobInviteBg.gif','AntTuanclose.gif','AntUserLogin.gif','fff5ca','F6F9FF','d11c4d','d11c4d');
				  return false;
			  }
		  }
		  else{
			  try{closeopendiv();}catch(err){}
			  if(data=="1")
			  {
				  alert("对不起，您还没有完善简历，请先完善您的简历！");
				  setTimeout(function(){window.location.href=SiteWebUrl+"Account/MemberResume.aspx?MenuID=4&sID=27";},10);
			  }
			  else
			  {
			 	 alert(data);
			  }
		  }
	  }
	});	
}
function JobInfoFav(allid)
{
	$.ajax({
	  url: "../public/ajax.aspx?action=jobfav&id="+allid,
	  cache: false,
	  success:function(data)
	  {
		  if(data=="0")
		  {	
			 try{closeopendiv();}catch(err){}
			 alert("恭喜您，职位收藏成功！");	
		  }
		  else{
			  try{closeopendiv();}catch(err){}
			  alert(data);
		  }
	  }
	});	
}
function hotkey() 
 { 
     var esc=window.event.keyCode; 
     if(esc==27) //判断是不是按的Esc键,27表示Esc键的keyCode. 
     { 
		try
		{
			PopupSelector.close();
        	closeopendiv();
		 }
		catch(err)
		{
		   //在此处理错误
		}
		try
		{
		    window.parent.closeopendiv();
		}
		catch(err)
		{
		   //在此处理错误
		}
     } 
 } 
document.onkeydown = hotkey; //当onkeydown(按键触发) 事件发生时调用hotkey函
function notice_setscool()
{
	if($_D('AntNewScroll'))
	{
		var box = $_D('AntNewScroll'),
		h = 30,
		go = 1,
		retimeout,
		retime = function() {
			retimeout = setTimeout(function() {
				go = 1;
			},
			1000);
		},
		stopTime = function() {
			clearTimeout(retimeout);
			retimeout = null;
		};
		box.innerHTML += box.innerHTML;
		box.onmouseover = function() {
			go = 0;
		};
		box.onmouseout = function() {
			go = 1
		};
	
		new
		function() {
			var stop = (box.scrollTop % h == 0) && !go;
			if (!stop)(box.scrollTop == +(box.scrollHeight / 2)) ? box.scrollTop = 0 : box.scrollTop++;
			setTimeout(arguments.callee, (box.scrollTop % h) ? 10 : 1500);
		};	
	}
}

function Company_setscool()
{
	if($_D('HotEnterprise'))
	{
		var box = $_D('HotEnterprise'),
		h = 73,
		go = 1,
		retimeout,
		retime = function() {
			retimeout = setTimeout(function() {
				go = 1;
			},
			1000);
		},
		stopTime = function() {
			clearTimeout(retimeout);
			retimeout = null;
		};
		box.innerHTML += box.innerHTML;
		box.onmouseover = function() {
			go = 0;
		};
		box.onmouseout = function() {
			go = 1
		};
	
		new
		function() {
			var stop = (box.scrollTop % h == 0) && !go;
			if (!stop)(box.scrollTop == +(box.scrollHeight / 2)) ? box.scrollTop = 0 : box.scrollTop++;
			setTimeout(arguments.callee, (box.scrollTop % h) ? 10 : 1500);
		};
	}
}
function checkaddjobword()
{
	var WordTitle=$("#txtWordTitle").val();
	var WordMan=$("#txtWordMan").val();
	var WordTel=$("#txtWordTel").val();
	var WordPwd=$("#txtWordPwd").val();
	var WordMark=$("#txtWordMark").val();
	var WordTypeid=$("#txtWordTypeid").val();
	if(WordTitle.length>250 || WordTitle.length<2)
	{
		alert("对不起，职位名称为2至250字之间！");
		$("#txtWordTitle").focus();
		return false;
	}
	if(WordMan.length<2 )
	{
		alert("对不起，请输入联系人！");
		$("#txtWordMan").focus();
		return false;
	}
	if(WordTel.length<5  )
	{
		alert("对不起，请输入您的联系方式！");
		$("#txtWordTel").focus();
		return false;
	}
	if(WordPwd.length>20 || WordPwd.length<5 )
	{
		alert("对不起，管理密码为5至20位之间！");
		$("#txtWordPwd").focus();
		return false;
	}
	if(WordMark.length>500 || WordMark=="请勿重复发布信息。需要对信息进行提高排名、修改、删除等操作。可点“管理此信息”通过您预设的“管理密码”进行相关操作。文明上网，理性发言。感谢您的合作！" )
	{
		alert("对不起，简要说明为500字以内！");
		$("#txtWordMark").focus();
		return false;
	}
	$.ajax({
	  url: "../public/ajax.aspx?action=addword&WordTitle="+escape(WordTitle)+"&WordMan="+escape(WordMan)+"&WordTel="+escape(WordTel)+"&WordPwd="+escape(WordPwd)+"&WordMark="+escape(WordMark)+"&WordTypeid="+WordTypeid,
	  cache: false,
	  success:function(data)
	  {
		  if(data==0)
		  {
			 alert("发布成功，稍等一会，请等待管理员审核通过！");
			 $("#txtWordTitle").val("");
			 $("#txtWordMan").val("");
			 $("#txtWordTel").val("");
			 $("#txtWordMark").val("请勿重复发布信息。需要对信息进行提高排名、修改、删除等操作。可点“管理此信息”通过您预设的“管理密码”进行相关操作。文明上网，理性发言。感谢您的合作！");
			 $("#txtWordPwd").val("");
		  }
		  else if(data==1)
		  {
			 alert("发布成功，需要对信息进行提高排名、修改、删除等操作。可点“管理此信息”通过您预设的“管理密码”进行相关操作！");
			 $("#txtWordTitle").val("");
			 $("#txtWordMan").val("");
			 $("#txtWordTel").val("");
			 $("#txtWordMark").val("请勿重复发布信息。需要对信息进行提高排名、修改、删除等操作。可点“管理此信息”通过您预设的“管理密码”进行相关操作。文明上网，理性发言。感谢您的合作！");
			 $("#txtWordPwd").val("");
		  }
		  else{
			alert(data);
		  }
	  }
	});	
	return false;
}
function LoadJobLogin()
{
	$.ajax({
	  url: "/public/ajax.aspx?action=checkjoblogin",
	  cache: false,
	  success:function(data)
	  {
		  if(data.length>0)
		  {
			 $("#login1div").hide();
			 var aa=data.split('÷');
			 $("#login2div").show();
			 $("#usernamediv").html(aa[3]);
			 $("#userjifendiv").html(aa[1]);
		  }
		  else{
			 $("#login2div").hide();
			 $("#login1div").show();
		  }
	  }
	});	
}

	 