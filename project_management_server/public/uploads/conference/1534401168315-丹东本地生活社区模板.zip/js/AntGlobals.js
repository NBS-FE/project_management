﻿var MoveObj=''
document.onmouseup=MUp
document.onmousemove=MMove
function MDown(Object){
	MoveObj=Object.id
	//document.all(MoveObj).setCapture()
	//pX=event.x-document.all(MoveObj).style.pixelLeft;
	//pY=event.y-document.all(MoveObj).style.pixelTop;
}
function MMove(){
	if(MoveObj!=''){
		//document.all(MoveObj).style.left=event.x-pX;
		//document.all(MoveObj).style.top=event.y-pY;
	}
}
function MUp(){
	if(MoveObj!=''){
		//document.all(MoveObj).releaseCapture();
		//MoveObj='';
	}
}
var reflash = false,
messageboxloadcomplete = false;
function SetMessageboxLoadComplete() {
	messageboxloadcomplete = true
}
if (document.all) {
	window.attachEvent('onload', SetMessageboxLoadComplete)
} else {
	window.addEventListener('load', SetMessageboxLoadComplete, false)
}
var isIe=(document.all)?true:false; 
var sctimer;
var tempwidth = 0,
tempheight = 0,
temppate = 1,
speedrate = 24,
interval_id = 0;
var newdiv = document.createElement("div");
var sdiv = document.createElement("div");
var contentdiv = document.createElement("div");
var Ant_width = 0,
Ant_height = 0,
Ant_src = '',
Ant_title = '',
Ant_Str = '',
Ant_width_p = 0,
Ant_height_div1 = 0;
document.writeln('<style type="text/css">body{ margin:0px !ipmortant; padding:0px  !ipmortant;}#blackbg{position:fixed;_position:absolute;}');
document.writeln('#blackcontentOuter{zoom:1; position:fixed!important;position:absolute;left:50%;top:45%;_top:expression((document.documentElement.scrollTop || document.body.scrollTop) + Math.round(50 * (document.documentElement.offsetHeight || document.body.clientHeight) / 100));}</style>');
function GetCookieValue(name) {
	var arr = document.cookie.match(new RegExp(name + "=([^&;]+)"));
	if (arr != null) {
		return decodeURI(arr[1])
	}
	return ""
}
function delCookie(name)
{
  var exp = new Date();
  exp.setTime(exp.getTime() - 1);
  var cval=GetCookieValue(name);
  if(cval!=null) document.cookie=name +"="+cval+";expires="+exp.toGMTString();
}
function CreateCookie(name,value)
{
	var date = new Date();
	date.setTime(date.getTime()+(30*24*60*60*1000));//30days
	var expires = "; expires="+date.toGMTString();
	document.cookie = name+"="+value+expires+"; path=/";
}
function ShowDailog(boxtitle, pwidth, pheight, psrc, showclose,bgimg,closeimg,iconImg,bigcolor,bordercolor,bgcolor1,bgcolor2) {
	var show = 'true';
	if (showclose == 'false') {
		show = 'false'
	}
	if (!messageboxloadcomplete) {
		window.clearInterval(interval_id);
		interval_id = window.setInterval("ShowDailog('" + boxtitle + "', " + pwidth + "," + pheight + ", '" + psrc + "','" + show + "','" + bgimg + "','" + closeimg + "','" + iconImg + "','" + bigcolor + "','" + bordercolor + "','"+bgcolor1+"','"+bgcolor2+"')", 200);
		return
	}
	setSelectState('hidden');
	window.clearInterval(interval_id);
	CreateCookie("AntOpenDailog","0");
	if (GetCookieValue("AntOpenDailog") == "") reflash = true;
	AntMessageBox.InitMsgDivData();
	Ant_title = boxtitle;
	Ant_width = pwidth;
	Ant_height = pheight;
	Ant_src = psrc;
	Ant_width_p = Ant_width - 22;
	Ant_height_div1 = Ant_height + 38;
	if(Ant_src.indexOf("?")==-1)
		Ant_src =Ant_src+"?ant="+Math.random()
	else
		Ant_src =Ant_src+"&ant="+Math.random()
	var ttst1="url(/public/js/img/"+bgimg+") no-repeat right top";
	if(bgimg=="")
		ttst1 = "";
	var ttst2="background:url(/public/js/img/"+closeimg+") no-repeat ;";
	if(closeimg=="")
		ttst2 = "";
	var ttst3='<img src="/public/js/img/'+iconImg+'" style="float:left" />';
	if(iconImg=="")
		ttst3 = "";
	var bgopacity='100'	
	if(bigcolor=='000')
		bgopacity='40';
	Ant_Str = '<div style=" position:absolute" id="massage_box"><div id="messageboxframecontainer" style="display:none;width:' + Ant_width + 'px; height:38px ;padding:10px; background:#'+bigcolor+';filter:alpha(opacity='+bgopacity+'); -moz-opacity:'+(bgopacity/100)+'; -kHTML-opacity: '+(bgopacity/100)+'; opacity: '+(bgopacity/100)+'; position:absolute; top:0; left:0; z-index:1"></div><div id="__messageboxback" onmousedown="MDown(massage_box)" style=" width:' + Ant_width + 'px;position:absolute; top:10px; left:10px; background:#'+bordercolor+'; z-index:1000;cursor:move;"><p id="messageboxclosebutton" style=" display:none;background:#'+bgcolor1+' '+ttst1+';width:' + Ant_width_p + 'px; height:41px; line-height:41px; padding:0 10px; border:1px solid #'+bgcolor2+'; border-bottom:none; font-size:18px; font-weight:bold; color:#fff;margin:0;">' + (show == 'true' ? '<a style=" display:block; width:20px; height:20px; '+ttst2+' line-height:100px; overflow:hidden; margin-top:8px; float:right" href="javascript:void(0);" onclick="javascript:closeopendiv()" title="关闭窗口">[关闭]</a>': '')+ttst3+'<span id="AntDialogTitle" name="AntDialogTitle" >' + Ant_title + '</span></p><iframe id="AntMessageBoxFrame" onload="AntMessageBox.ResizeIframe()" scrolling="no" src="' + Ant_src + '" frameborder="0" height="0" width="' + Ant_width + '"></iframe></div></div>';
	AntMessageBox.scroolMsgeffect();
}
function closeopendiv() {
	setSelectState('');
	if (GetCookieValue("AntOpenDailog") == "1") {
		delCookie("AntOpenDailog");
		window.location.reload();
	} else {
		contentdiv.style.width = '10px';
		contentdiv.style.height = '10px';
		contentdiv.innerHTML = "";
		Ant_width = 0,
		Ant_height = 0,
		Ant_src = '',
		Ant_title = '',
		Ant_Str = '';
		tempwidth = 0,
		tempheight = 0,
		temppate = 1,
		contentdiv.style.display = "none";
		newdiv.style.display = "none"
		newdiv.style.filter = "alpha(opacity=0)";
		newdiv.style.opacity = 0;
	}
}
var AntMessageBox = {
	SetIframeWidth:function(Ant_width){
		var _frame = document.getElementById("AntMessageBoxFrame");
		_frame.width = Ant_width;
		contentdiv.style.width = Ant_width + "px";
		var f = document.getElementById("messageboxframecontainer");
		f.style.width = Ant_width + "px";
		document.getElementById('__messageboxback').style.width = Ant_width + "px";
	},
	SetIframeHeight:function(Ant_height){
		var _frame = document.getElementById("AntMessageBoxFrame");
		_frame.height = Ant_height;
		contentdiv.style.height = Ant_height + "px";
		var f = document.getElementById("messageboxframecontainer");
		f.style.height = Ant_height + "px";
		document.getElementById('__messageboxback').style.height = Ant_height + "px";
	},
	ResizeIframe: function() {
		try {
			var _frame = document.getElementById("AntMessageBoxFrame");
			var height = 0,
			width = 0;
			var f = document.getElementById("messageboxframecontainer");
			var closebutton = document.getElementById("messageboxclosebutton");
			try {
				_frame.height = 0;
				width = Math.max(_frame.contentWindow.document.documentElement.scrollWidth, _frame.contentWindow.document.body.scrollWidth);
				height = Math.max(_frame.contentWindow.document.documentElement.scrollHeight, _frame.contentWindow.document.body.scrollHeight)
				//alert(_frame.contentWindow.document.documentElement.scrollWidth);
			} catch(e) {}
			
			if (height > 0) {
				Ant_height = height;
				Ant_height_div1 = Ant_height + 48;
				Ant_width = width;
				Ant_width_p = Ant_width - 22
			}
			
			contentdiv.style.width = Ant_width + "px";
			contentdiv.style.height = Ant_height + "px";
			contentdiv.style.margin = "-" + Ant_height / 2 + "px 0px 0px -" + Ant_width / 2 + "px";
			_frame.width = Ant_width;
			_frame.height = Ant_height;
			closebutton.style.width = Ant_width_p + "px";
			closebutton.style.display = "inline-block";
			f.style.width = Ant_width + "px";
			f.style.height = AntMessageBox.setheightauto(Ant_height_div1) + "px";
			f.style.display = "block";
			document.getElementById('__messageboxback').style.width = Ant_width + "px";
			document.getElementById("messageboxclosebutton").style.display = "inline-block"
		} catch(e1) {}
	},
	getMsgDivHeight: function() {
		var a = document.body.scrollHeight;
		var b = window.screen.height;
		return a > b ? a: b
	},
	InitMsgDivData: function() {
		newdiv.id = "blackbg";
		newdiv.style.display = "none";
		newdiv.style.zIndex = '99990';
		newdiv.style.backgroundColor = "#000000";
		newdiv.style.filter = "alpha(opacity=60)";
		newdiv.style.opacity = 0.6;
		newdiv.style.display = "block";
		newdiv.style.top = "0px";
		newdiv.style.left = "0px";
		newdiv.style.width = "100%";
		newdiv.style.height = AntMessageBox.getMsgDivHeight() + "px";
		contentdiv.id = "blackcontentOuter";
		contentdiv.style.display = "none";
		contentdiv.style.zIndex = '99991';
		contentdiv.style.width = '10px';
		contentdiv.style.height = '10px';
		contentdiv.style.margin = '-5px 0px 0px -5px';
		contentdiv.style.backgroundColor = "";
		document.body.appendChild(newdiv);
		document.body.appendChild(contentdiv)
	},
	scroolMsgeffect: function() {
		contentdiv.style.display = "block";
		AntMessageBox.scroolMsgdiv()
	},
	getiecopy: function() {
		var bro = navigator.userAgent.toLowerCase();
		if (/msie/.test(bro)) return bro.match(/msie ([\d.]*);/)[1]
	},
	setheightauto: function(input) {
		if (document.all) {
			if (AntMessageBox.getiecopy() < 7.0) return input + 3
		}
		return input
	},
	scroolMsgdiv: function() {
		tempwidth = Ant_width;
		tempheight = Ant_height;
		contentdiv.innerHTML = Ant_Str;
		contentdiv.style.width = tempwidth + "px";
		contentdiv.style.height = tempheight + "px";
		contentdiv.style.margin = "-" + tempheight / 2 + "px 0px 0px -" + tempwidth / 2 + "px"
	}
};
function setSelectState(state) 
{ 
 var objl=document.getElementsByTagName('select'); 
 for(var i=0;i<objl.length;i++) 
 { 
 objl[i].style.visibility=state; 
 } 
} 

